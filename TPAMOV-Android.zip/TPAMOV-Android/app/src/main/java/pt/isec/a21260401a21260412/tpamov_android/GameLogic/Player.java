package pt.isec.a21260401a21260412.tpamov_android.GameLogic;

public class Player {
    public String name,photoPath;


    public Player (String name, String photoPath){
        this.name = name;
        this.photoPath = photoPath;
    }

}
