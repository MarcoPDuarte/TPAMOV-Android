package pt.isec.a21260401a21260412.tpamov_android.GameLogic;

public class GameLogic {



    public GameLogic(){

    }
}
